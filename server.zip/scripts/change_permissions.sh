#!/bin/bash

DIR="/home/ubuntu/server/"

sudo chmod -R 777 $DIR
